package com.cg.app.ProfileServicWebpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfileServicWebpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfileServicWebpageApplication.class, args);
	}

}

