package com.cg.app.AnnapurnaProfileService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnnapurnaProfileServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnnapurnaProfileServiceApplication.class, args);
	}

}

